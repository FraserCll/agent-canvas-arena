const { FastMCP } = require("fastmcp");
const { ethers } = require("ethers");
require("dotenv").config({ path: ".env.production" });

const provider = new ethers.JsonRpcProvider("https://mainnet.base.org");
const contractAddress = "0x11284A7e4c13375a7bff912122447BC86E0CbDBB";
const abi = [
    "function getGrid() external view returns (uint32[32][32])",
    "function lastPainter(uint256, uint256) external view returns (address)",
    "function PIXEL_PRICE() external view returns (uint256)",
    "function usdc() external view returns (address)"
];

const contract = new ethers.Contract(contractAddress, abi, provider);

const mcp = new FastMCP("Agent-Canvas-Service");

mcp.addTool({
    name: "read_canvas",
    description: "Returns the current 32x32 pixel grid data.",
    execute: async () => {
        const grid = await contract.getGrid();
        return { grid: grid.map(row => row.map(p => Number(p))) };
    }
});

mcp.addTool({
    name: "get_pixel_owner",
    description: "Returns the address of the last agent to paint a specific pixel.",
    parameters: {
        x: { type: "number", description: "X coordinate (0-31)" },
        y: { type: "number", description: "Y coordinate (0-31)" }
    },
    execute: async ({ x, y }) => {
        const owner = await contract.lastPainter(x, y);
        return { owner };
    }
});

mcp.addTool({
    name: "generate_payment_uri",
    description: "Generates a transaction intent for painting a pixel, including the required USDC approval.",
    parameters: {
        x: { type: "number", description: "X coordinate" },
        y: { type: "number", description: "Y coordinate" },
        color: { type: "number", description: "Hex color (uint32)" }
    },
    execute: async ({ x, y, color }) => {
        const usdcAddress = await contract.usdc();
        const price = await contract.PIXEL_PRICE();
        
        return {
            steps: [
                {
                    target: usdcAddress,
                    function: "approve(address,uint256)",
                    args: [contractAddress, price.toString()],
                    description: "Approve PixelGrid to spend USDC"
                },
                {
                    target: contractAddress,
                    function: "setPixel(uint256,uint256,uint32)",
                    args: [x, y, color],
                    description: "Set pixel color"
                }
            ]
        };
    }
});

const port = process.env.PORT || 3000;
mcp.server.listen(port).then(() => {
    console.log(`MCP Server running on port ${port}`);
});
